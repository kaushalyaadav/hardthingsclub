import Link from "next/link";
import { redirect } from "next/navigation";
import BottomNav from "@/components/member/BottomNav";
import { createClient } from "@/lib/supabaseServer";
import { getISTDateString, getProgrammeDaysElapsed, PROGRAMME_TOTAL_DAYS } from "@/lib/utils";
import { isMovementDay } from "@/lib/utils";

export default async function HomePage() {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/");

  const today = getISTDateString();
  const { data: entries } = await supabase.from("log_entries").select("*").eq("user_id", user.id).order("entry_date", { ascending: false });
  const todayEntry = entries?.find((e) => e.entry_date === today);
  const totalDays = getProgrammeDaysElapsed(today);
  const loggedDays = entries?.length ?? 0;
  const movementDays = (entries ?? []).filter((e) => isMovementDay(e.session_types)).length;
  const stillDays = (entries ?? []).filter((e) => e.breathwork_minutes > 0).length;
  const consistency = totalDays > 0 ? Math.round((loggedDays / totalDays) * 100) : 0;

  return (
    <main className="mx-auto max-w-[420px] p-4 pb-20 space-y-4">
      <header>
        <h1 className="text-xl font-semibold">Today</h1>
        <p className="text-sm text-neutral-600">Day {totalDays} of {PROGRAMME_TOTAL_DAYS}</p>
      </header>
      <section className="card p-4">
        <p className="text-sm text-neutral-500">Logging consistency</p>
        <p className="text-3xl font-semibold">{consistency}%</p>
        <p className="text-sm text-neutral-600">{loggedDays} logged out of {totalDays} days</p>
      </section>
      <section className="grid grid-cols-2 gap-3">
        <div className="card p-4">
          <p className="text-xs text-neutral-500">Movement days</p>
          <p className="text-xl font-semibold">{movementDays}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs text-neutral-500">Still days</p>
          <p className="text-xl font-semibold">{stillDays}</p>
        </div>
      </section>

      {todayEntry ? (
        <section className="card p-4 space-y-2">
          <p className="text-sm font-medium text-green-600">Logged for today (IST)</p>
          <p className="text-sm text-neutral-700">Sessions: {todayEntry.session_types.join(", ") || "-"}</p>
          <p className="text-sm text-neutral-700">Duration: {todayEntry.session_duration_minutes} min</p>
          <p className="text-sm text-neutral-700">Breathwork: {todayEntry.breathwork_minutes} min</p>
          <Link href={`/log?edit=${todayEntry.id}`} className="text-sm underline">Edit today&apos;s log</Link>
        </section>
      ) : (
        <section className="space-y-2">
          <Link href="/log" className="block text-center bg-black text-white rounded-xl py-3 font-medium">+ Log today&apos;s activity</Link>
          <p className="text-xs text-center text-neutral-500">Log everyday - even rest days count</p>
        </section>
      )}
      <BottomNav />
    </main>
  );
}

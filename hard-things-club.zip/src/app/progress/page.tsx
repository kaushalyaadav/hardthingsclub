import { redirect } from "next/navigation";
import BottomNav from "@/components/member/BottomNav";
import { createClient } from "@/lib/supabaseServer";
import { PROGRAMME_MONTHS, getDaysInMonth, isMovementDay } from "@/lib/utils";

export default async function ProgressPage() {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/");

  const { data: logs } = await supabase.from("log_entries").select("*").eq("user_id", user.id);

  const rowFor = (year: number, month: number) => (logs ?? []).filter((l) => {
    const d = new Date(`${l.entry_date}T00:00:00+05:30`);
    return d.getUTCFullYear() === year && d.getUTCMonth() + 1 === month;
  });

  return (
    <main className="mx-auto max-w-[420px] p-4 pb-20">
      <h1 className="text-xl font-semibold mb-3">Progress</h1>
      <div className="overflow-x-auto">
        <table className="min-w-[560px] text-sm">
          <thead>
            <tr className="text-left">
              <th className="py-2">Metric</th>
              {PROGRAMME_MONTHS.map((m) => <th key={m.label} className="py-2 px-2">{m.label}</th>)}
            </tr>
          </thead>
          <tbody>
            <tr><td>Total days</td>{PROGRAMME_MONTHS.map((m) => <td key={m.label} className="px-2">{getDaysInMonth(m.year, m.month)}</td>)}</tr>
            <tr><td>Logged days</td>{PROGRAMME_MONTHS.map((m) => <td key={m.label} className="px-2">{rowFor(m.year, m.month).length}</td>)}</tr>
            <tr><td>Movement days</td>{PROGRAMME_MONTHS.map((m) => <td key={m.label} className="px-2">{rowFor(m.year, m.month).filter((r) => isMovementDay(r.session_types)).length}</td>)}</tr>
            <tr><td>Still days</td>{PROGRAMME_MONTHS.map((m) => <td key={m.label} className="px-2">{rowFor(m.year, m.month).filter((r) => r.breathwork_minutes > 0).length}</td>)}</tr>
          </tbody>
        </table>
      </div>
      <BottomNav />
    </main>
  );
}

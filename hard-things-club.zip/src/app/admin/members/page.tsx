import Link from "next/link";
import { createClient } from "@/lib/supabaseServer";
import { getProgrammeDaysElapsed, isMovementDay } from "@/lib/utils";

export default async function MembersPage() {
  const supabase = createClient();
  const { data: members } = await supabase.from("profiles").select("id,full_name").eq("role", "member");
  const { data: logs } = await supabase.from("log_entries").select("*");
  const totalDays = getProgrammeDaysElapsed();

  return (
    <div className="card p-4">
      <h1 className="text-xl font-semibold">All members</h1>
      <p className="text-sm text-blue-600">All numbers are cumulative from 1 April 2026</p>
      <table className="w-full mt-4 text-sm">
        <thead><tr><th className="text-left">Member</th><th>Days since Apr 1</th><th>Logged</th><th>Consistency</th><th>Movement</th><th>Still</th></tr></thead>
        <tbody>
          {(members ?? []).map((m) => {
            const my = (logs ?? []).filter((l) => l.user_id === m.id);
            const consistency = totalDays ? Math.round((my.length / totalDays) * 100) : 0;
            return (
              <tr key={m.id} className="border-t">
                <td><Link className="underline" href={`/admin/member-logs?id=${m.id}`}>{m.full_name}</Link></td>
                <td>{totalDays}</td><td>{my.length}</td><td>{consistency}%</td>
                <td>{my.filter((x) => isMovementDay(x.session_types)).length}</td>
                <td>{my.filter((x) => x.breathwork_minutes > 0).length}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

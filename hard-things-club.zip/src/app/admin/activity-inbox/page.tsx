import { createClient } from "@/lib/supabaseServer";
import { formatDate, getISTDateString } from "@/lib/utils";

export default async function ActivityInboxPage({ searchParams }: { searchParams: { date?: string; tab?: string } }) {
  const supabase = createClient();
  const selectedDate = searchParams.date || getISTDateString();
  const tab = searchParams.tab || "all";

  const { data: members } = await supabase.from("profiles").select("id,full_name").eq("role", "member");
  const { data: entries } = await supabase.from("log_entries").select("*").eq("entry_date", selectedDate);
  const loggedSet = new Set((entries ?? []).map((e) => e.user_id));
  const notLogged = (members ?? []).filter((m) => !loggedSet.has(m.id));

  const shown =
    tab === "logged" ? entries ?? [] :
    tab === "not-logged" ? [] :
    entries ?? [];

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <h1 className="text-xl font-semibold">Activity inbox</h1>
        <p className="text-sm text-neutral-600">All member activity in one feed</p>
        <p className="text-sm mt-1">Date: {selectedDate}</p>
      </div>
      <div className="card p-4">
        <div className="flex gap-2 text-sm mb-3">
          <a className="underline" href={`/admin/activity-inbox?date=${selectedDate}&tab=all`}>All ({(members ?? []).length})</a>
          <a className="underline" href={`/admin/activity-inbox?date=${selectedDate}&tab=logged`}>Logged ({(entries ?? []).length})</a>
          <a className="underline" href={`/admin/activity-inbox?date=${selectedDate}&tab=not-logged`}>Not logged ({notLogged.length})</a>
        </div>
        <div className="space-y-2">
          {tab !== "not-logged" && shown.map((e) => {
            const member = members?.find((m) => m.id === e.user_id);
            return (
              <div key={e.id} className="border rounded p-3">
                <p className="text-xs text-neutral-500">{member?.full_name} · {formatDate(e.entry_date)}</p>
                <p className="text-sm">{e.session_types.join(", ") || "No activity logged"} · Breathwork {e.breathwork_minutes} min</p>
                {e.notes && <p className="text-sm text-neutral-700 mt-1">{e.notes}</p>}
              </div>
            );
          })}
          {(tab === "not-logged" || tab === "all") && notLogged.map((m) => (
            <div key={m.id} className="border border-dashed rounded p-3 text-sm text-neutral-600">{m.full_name} - no activity logged</div>
          ))}
        </div>
      </div>
    </div>
  );
}

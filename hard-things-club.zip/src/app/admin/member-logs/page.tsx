import { createClient } from "@/lib/supabaseServer";
import { formatDate } from "@/lib/utils";

export default async function MemberLogsPage({ searchParams }: { searchParams: { id?: string } }) {
  const supabase = createClient();
  const { data: members } = await supabase.from("profiles").select("id,full_name").eq("role", "member");
  const selectedId = searchParams.id || members?.[0]?.id;
  const selected = members?.find((m) => m.id === selectedId);
  const { data: logs } = await supabase.from("log_entries").select("*").eq("user_id", selectedId).order("entry_date", { ascending: false });

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <h1 className="text-xl font-semibold">Member logs</h1>
        <form className="mt-2">
          <select name="id" defaultValue={selectedId} className="border rounded px-2 py-1">
            {(members ?? []).map((m) => <option key={m.id} value={m.id}>{m.full_name}</option>)}
          </select>
          <button className="ml-2 border rounded px-3 py-1">View</button>
        </form>
        <p className="text-sm text-neutral-600 mt-2">{selected?.full_name}</p>
      </div>
      <div className="card p-4">
        <h2 className="font-medium mb-2">Daily log feed</h2>
        <div className="space-y-2">
          {(logs ?? []).map((e) => (
            <div key={e.id} className={`border rounded p-3 ${e.session_types.includes("Rest") ? "border-dashed" : ""}`}>
              <p className="text-xs text-neutral-500">{formatDate(e.entry_date)}</p>
              <p className="text-sm">{e.session_types.join(", ") || "No activity logged"}</p>
              <p className="text-xs text-neutral-600">Duration: {e.session_duration_minutes} min · Breathwork: {e.breathwork_minutes} min</p>
              {e.notes && <p className="text-sm mt-1 whitespace-pre-wrap">{e.notes}</p>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

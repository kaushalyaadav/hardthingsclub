import { createClient } from "@/lib/supabaseServer";
import { getProgrammeDaysElapsed } from "@/lib/utils";

export default async function AdminLoggingHabitPage() {
  const supabase = createClient();
  const { data: members } = await supabase.from("profiles").select("id,full_name").eq("role", "member");
  const { data: logs } = await supabase.from("log_entries").select("user_id,entry_date");
  const totalDays = getProgrammeDaysElapsed();
  const rows = (members ?? []).map((m) => {
    const logged = (logs ?? []).filter((l) => l.user_id === m.id).length;
    const pct = totalDays ? Math.round((logged / totalDays) * 100) : 0;
    return { ...m, logged, pct };
  });

  return (
    <div className="card p-4">
      <h1 className="text-xl font-semibold">Logging habit</h1>
      <p className="text-sm text-neutral-600">Monthly view</p>
      <table className="w-full mt-4 text-sm">
        <thead><tr><th className="text-left">Member</th><th className="text-left">Month</th><th>Total</th><th>Logged</th><th>%</th></tr></thead>
        <tbody>
          {rows.map((r) => <tr key={r.id} className="border-t"><td>{r.full_name}</td><td>Current</td><td>{totalDays}</td><td>{r.logged}</td><td>{r.pct}%</td></tr>)}
        </tbody>
      </table>
    </div>
  );
}

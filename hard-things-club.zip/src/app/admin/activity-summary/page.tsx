import { createClient } from "@/lib/supabaseServer";
import { getProgrammeDaysElapsed, isMovementDay } from "@/lib/utils";

export default async function ActivitySummaryPage() {
  const supabase = createClient();
  const { data: members } = await supabase.from("profiles").select("id,full_name").eq("role", "member");
  const { data: logs } = await supabase.from("log_entries").select("*");
  const totalDays = getProgrammeDaysElapsed();

  const rows = (members ?? []).map((m) => {
    const my = (logs ?? []).filter((l) => l.user_id === m.id);
    return {
      name: m.full_name,
      movement: my.filter((x) => isMovementDay(x.session_types)).length,
      still: my.filter((x) => x.breathwork_minutes > 0).length
    };
  });

  return (
    <div className="card p-4">
      <h1 className="text-xl font-semibold">Activity summary</h1>
      <table className="w-full mt-4 text-sm">
        <thead><tr><th className="text-left">Member</th><th>Total days</th><th>Movement days</th><th>Still days</th></tr></thead>
        <tbody>{rows.map((r) => <tr key={r.name} className="border-t"><td>{r.name}</td><td>{totalDays}</td><td>{r.movement}</td><td>{r.still}</td></tr>)}</tbody>
      </table>
    </div>
  );
}

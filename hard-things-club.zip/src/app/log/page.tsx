import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabaseServer";
import { getISTDateString } from "@/lib/utils";
import LogForm from "@/components/member/LogForm";

export default async function LogPage({ searchParams }: { searchParams: { edit?: string } }) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/");

  const today = getISTDateString();
  let existing = null as any;

  if (searchParams.edit) {
    const { data } = await supabase.from("log_entries").select("*").eq("id", searchParams.edit).single();
    existing = data;
  } else {
    const { data } = await supabase.from("log_entries").select("*").eq("user_id", user.id).eq("entry_date", today).maybeSingle();
    existing = data;
  }

  return (
    <main className="mx-auto max-w-[420px] p-4 space-y-4">
      <h1 className="text-xl font-semibold">Log today</h1>
      <p className="text-sm text-neutral-600">{today} (IST)</p>
      <LogForm
        userId={user.id}
        entryDate={today}
        initial={
          existing
            ? {
                id: existing.id,
                session_types: existing.session_types,
                session_duration_minutes: existing.session_duration_minutes,
                breathwork_minutes: existing.breathwork_minutes,
                notes: existing.notes || ""
              }
            : undefined
        }
      />
    </main>
  );
}

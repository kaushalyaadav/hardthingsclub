import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabaseServer";

export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");
  const origin = requestUrl.origin;

  if (!code) return NextResponse.redirect(`${origin}/`);

  const supabase = createClient();
  await supabase.auth.exchangeCodeForSession(code);
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user?.email) return NextResponse.redirect(`${origin}/`);
  const allowedEmails = (process.env.ALLOWED_EMAILS || "").split(",").map((e) => e.trim().toLowerCase());
  if (!allowedEmails.includes(user.email.toLowerCase())) {
    await supabase.auth.signOut();
    return NextResponse.redirect(`${origin}/?error=not-allowed`);
  }

  return NextResponse.redirect(`${origin}/home`);
}

import { redirect } from "next/navigation";
import Link from "next/link";
import BottomNav from "@/components/member/BottomNav";
import { createClient } from "@/lib/supabaseServer";
import { formatDate, isMovementDay } from "@/lib/utils";

export default async function JournalPage() {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/");

  const { data: logs } = await supabase.from("log_entries").select("*").eq("user_id", user.id).order("entry_date", { ascending: false });
  const entries = logs ?? [];

  return (
    <main className="mx-auto max-w-[420px] p-4 pb-20 space-y-3">
      <h1 className="text-xl font-semibold">Your journal</h1>
      <p className="text-sm text-neutral-600">Every log, in one place</p>
      <div className="grid grid-cols-3 gap-2">
        <div className="card p-2 text-center"><p className="text-xs">Entries</p><p className="font-semibold">{entries.length}</p></div>
        <div className="card p-2 text-center"><p className="text-xs">Movement</p><p className="font-semibold">{entries.filter((e) => isMovementDay(e.session_types)).length}</p></div>
        <div className="card p-2 text-center"><p className="text-xs">Still</p><p className="font-semibold">{entries.filter((e) => e.breathwork_minutes > 0).length}</p></div>
      </div>
      {entries.length === 0 ? (
        <div className="card p-5 text-center border-dashed">
          <p className="mb-2">No entries yet</p>
          <Link href="/log" className="inline-block bg-black text-white rounded-lg px-4 py-2 text-sm">Log today</Link>
        </div>
      ) : (
        entries.map((e) => (
          <div key={e.id} className={`card p-3 ${e.session_types.includes("Rest") ? "border-dashed" : ""}`}>
            <p className="text-xs text-neutral-500">{formatDate(e.entry_date)}</p>
            <p className="text-sm mt-1">{e.session_types.join(", ") || "No session"}</p>
            <p className="text-xs text-neutral-600">Breathwork {e.breathwork_minutes} min</p>
            {e.notes && <p className="text-sm mt-2 whitespace-pre-wrap">{e.notes}</p>}
          </div>
        ))
      )}
      <BottomNav />
    </main>
  );
}

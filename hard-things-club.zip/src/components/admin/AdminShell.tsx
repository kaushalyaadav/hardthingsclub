import Link from "next/link";

const links = [
  { href: "/admin", label: "Logging habit" },
  { href: "/admin/activity-summary", label: "Activity summary" },
  { href: "/admin/members", label: "All members" },
  { href: "/admin/member-logs", label: "Member logs" },
  { href: "/admin/activity-inbox", label: "Activity inbox" }
];

export default function AdminShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen grid grid-cols-[220px_1fr]">
      <aside className="border-r p-4 space-y-2">
        <h2 className="font-semibold mb-4">Hard Things Club</h2>
        {links.map((link) => (
          <Link key={link.href} href={link.href} className="block text-sm py-2">
            {link.label}
          </Link>
        ))}
        <p className="text-xs text-neutral-500 pt-6">Kaushal - Coach</p>
      </aside>
      <main className="p-6 bg-neutral-50">{children}</main>
    </div>
  );
}

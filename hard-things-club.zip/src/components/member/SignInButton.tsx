"use client";

import { createClient } from "@/lib/supabaseBrowser";

export default function SignInButton() {
  const onSignIn = async () => {
    const supabase = createClient();
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth/callback` }
    });
  };

  return (
    <button onClick={onSignIn} className="w-full rounded-xl bg-black text-white py-3 text-sm font-medium">
      Continue with Google
    </button>
  );
}

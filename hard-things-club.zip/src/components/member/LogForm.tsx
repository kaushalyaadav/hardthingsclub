"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabaseBrowser";
import { SESSION_TYPES, SessionType } from "@/lib/types";

type Props = {
  userId: string;
  entryDate: string;
  initial?: {
    id?: string;
    session_types: SessionType[];
    session_duration_minutes: number;
    breathwork_minutes: number;
    notes: string;
  };
};

export default function LogForm({ userId, entryDate, initial }: Props) {
  const [sessionTypes, setSessionTypes] = useState<SessionType[]>(initial?.session_types ?? []);
  const [duration, setDuration] = useState(initial?.session_duration_minutes ?? 0);
  const [breathwork, setBreathwork] = useState(initial?.breathwork_minutes ?? 0);
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [saving, setSaving] = useState(false);
  const router = useRouter();

  const isRest = useMemo(() => sessionTypes.includes("Rest"), [sessionTypes]);

  const toggleType = (type: SessionType) => {
    if (type === "Rest") {
      setSessionTypes((prev) => (prev.includes("Rest") ? [] : ["Rest"]));
      setDuration(0);
      return;
    }
    setSessionTypes((prev) => {
      const withoutRest = prev.filter((t) => t !== "Rest");
      return withoutRest.includes(type) ? withoutRest.filter((t) => t !== type) : [...withoutRest, type];
    });
  };

  const onSave = async () => {
    setSaving(true);
    const supabase = createClient();
    await supabase.from("log_entries").upsert(
      {
        id: initial?.id,
        user_id: userId,
        entry_date: entryDate,
        session_types: sessionTypes,
        session_duration_minutes: isRest ? 0 : duration,
        breathwork_minutes: breathwork,
        notes
      },
      { onConflict: "user_id,entry_date" }
    );
    setSaving(false);
    router.push("/home");
    router.refresh();
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-2">
        {SESSION_TYPES.map((type) => {
          const active = sessionTypes.includes(type);
          return (
            <button
              key={type}
              type="button"
              onClick={() => toggleType(type)}
              className={`rounded-full px-3 py-2 text-sm border ${type === "Rest" ? "border-dashed" : ""} ${active ? "bg-black text-white border-black" : "border-neutral-300"}`}
            >
              {type}
            </button>
          );
        })}
      </div>
      {isRest ? (
        <p className="text-xs text-neutral-600">Rest day logged. This won&apos;t count as a movement day but your logging streak stays alive.</p>
      ) : (
        <div className="card p-3">
          <label className="text-sm">Session duration (min)</label>
          <input type="number" min={0} value={duration} onChange={(e) => setDuration(Number(e.target.value))} className="mt-2 w-full border rounded-lg px-3 py-2" />
        </div>
      )}
      <div className="card p-3">
        <label className="text-sm">Breathwork duration (0 if skipped)</label>
        <input type="number" min={0} value={breathwork} onChange={(e) => setBreathwork(Number(e.target.value))} className="mt-2 w-full border rounded-lg px-3 py-2" />
      </div>
      <div className="card p-3">
        <label className="text-sm">Notes & message to Kaushal</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={5}
          className="mt-2 w-full border rounded-lg px-3 py-2"
          placeholder={"How was the workout?\nAny struggles today?\nAny highlights or wins?\nAnything you need help with?"}
        />
      </div>
      <button disabled={saving} onClick={onSave} className="w-full rounded-xl bg-black text-white py-3">
        {saving ? "Saving..." : "Save log"}
      </button>
    </div>
  );
}
